# assignment2-auth-app

- Run `npm install` to install all required dependencies.
- Run `npm start` to start server.
- Navigate to `localhost:3000/register` to create new account.
- Navigate to `localhost:3000/register` to login to existing account.
